#JAVADA SUPER ANAHTAR KELİMESİ VE KULLANIMI


Super de this anahtar sözcüğü gibi genellikle kalıtım ile beraber kullanılır. Veri üyelerinin private olarak koruyan bir üst sınıf oluşturmak istediğimiz zamanlar olacaktır. Bu durumda bir alt sınıf için bu değişkenlere doğrudan erişim veya ilk değer ataması söz konusu değildir. Bir alt sınıfın üst sınıfa göndermede bulunması gerekirse super anahtar sözcüğü kullanılır
superin iki genel formu vardır.
1-üst sınıf yapılandırıcısını çağırmak //encapsulation gibi
2-bir üst sınıfın alt sınıfının üyesi tarafından gizlenen bir üyeye erişmek için kullanılır.//this gibidir
Bu şekilde yazılır===super(parametre_listesi)




Youtube Kanalımız: BMDersleri

Bağlantı: https://www.youtube.com/c/bmdersleri

Kısa Bağlantı: https://bit.ly/32k9MnJ

Github Adresimiz: https://github.com/bmdersleri
